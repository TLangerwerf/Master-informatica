<?php

declare(strict_types=1);

require_once __DIR__ . '/../backend/db.php';
require_once __DIR__ . '/../backend/auth.php';
if (!function_exists('current_user')) {
  die("auth.php is niet geladen OF current_user() ontbreekt. Check pad en functies.");
}

session_start();

$user = current_user();
$isLoggedIn = (bool)$user;
$isTeacher  = $user && ($user['role'] ?? '') === 'teacher';

$error = '';

// ---- Login verwerken (homepage blijft altijd zichtbaar) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_verify($_POST['csrf'] ?? '');

  $username = trim((string)($_POST['username'] ?? ''));
  $password = (string)($_POST['password'] ?? '');

  if ($username === '' || $password === '') {
    $error = 'Vul gebruikersnaam en wachtwoord in.';
  } else {
    if (login_attempt($username, $password)) {
      $u = current_user();
      header('Location: ' . (($u['role'] ?? '') === 'teacher' ? '/teacher-sites.php' : '/sites.php'));
      exit;
    }
    $error = 'Onjuiste gebruikersnaam of wachtwoord.';
  }
}

// ---- Sites uit database ophalen (15 stuks uit klas VWO 6 = class_id 1) ----
// Later kun je dit dynamisch maken of op basis van ingelogde docent/leerling.
$classId = 1;

$sql = "
SELECT
  s.id,
  s.title,
  s.url,
  s.class_id,
  s.group_id,
  g.name AS group_name,
  COUNT(r.id) AS review_count
FROM sites s
JOIN groups g ON g.id = s.group_id
LEFT JOIN reviews r ON r.site_id = s.id
WHERE s.class_id = :class_id
GROUP BY s.id, s.title, s.url, s.class_id, s.group_id, g.name
ORDER BY s.group_id ASC
LIMIT 15
";

$stmt = db()->prepare($sql);
$stmt->execute([':class_id' => $classId]);
$sites = $stmt->fetchAll();
?>
<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Website Review Platform – Home</title>

  <!-- assets/ zit onder frontend/ (webroot), dus paden starten met /assets/... -->
  <link rel="stylesheet" href="/assets/css/ui.css">
  <link rel="stylesheet" href="/assets/css/home.css">
  <script defer src="/assets/scripts/home.js"></script>
</head>

<body>
<header>
  <div class="topbar">
    <div class="brand">
      <div class="logo">WRP</div>
      <div>
        <div>Website Review Platform</div>
        <div class="muted">Home (portaal)</div>
      </div>
    </div>

    <div class="actions">
      <?php if ($isLoggedIn): ?>
        <span class="pill info">Ingelogd: <?= h($user['display_name']) ?></span>
        <a class="btn" href="/logout.php">Uitloggen</a>
      <?php else: ?>
        <span class="pill info">Gast</span>
      <?php endif; ?>
    </div>
  </div>
</header>

<div class="wrap">

  <!-- Intro -->
  <section class="panel">
    <div class="title">Websites overzicht (VWO 6)</div>
    <div class="muted">
      Alle websites zijn zichtbaar zonder inloggen. Inloggen is nodig om docent- of leerlingfunctionaliteit te gebruiken.
    </div>

    <div class="notice">
      <?php if ($isTeacher): ?>
        Je bent ingelogd als <strong>docent</strong>. Docentacties zijn beschikbaar (reviews/aanpassen).
      <?php elseif ($isLoggedIn): ?>
        Je bent ingelogd als <strong>leerling</strong>. Je kunt straks reviews plaatsen via de leerlingenomgeving.
      <?php else: ?>
        Je bent niet ingelogd. Je kunt websites bekijken, maar niet beheren.
      <?php endif; ?>
    </div>
  </section>

  <!-- Login panel (alleen tonen als niet ingelogd) -->
  <?php if (!$isLoggedIn): ?>
    <section class="panel" style="margin-top:16px;">
      <div class="title" style="font-size:16px;">Inloggen</div>

      <?php if ($error): ?>
        <div class="notice"><?= h($error) ?></div>
      <?php else: ?>
        <div class="muted">Log in met je docent- of leerlingaccount.</div>
      <?php endif; ?>

        <div class="field">
          <label class="muted" for="username">Gebruikersnaam</label>
          <input id="username" name="username" autocomplete="username" required>
        </div>

        <div class="field">
          <label class="muted" for="password">Wachtwoord</label>
          <input id="password" name="password" type="password" autocomplete="current-password" required>
        </div>

        <div class="field">
          <label class="muted">&nbsp;</label>
          <button class="btn primary" type="submit">Inloggen</button>
        </div>

        <div class="field">
          <label class="muted">&nbsp;</label>
          <button class="btn" type="button" id="togglePw">Toon wachtwoord</button>
        </div>
      </form>
    </section>
  <?php endif; ?>

  <!-- Websites grid -->
  <section class="panel" style="margin-top:16px;">
    <div class="title">Beschikbare websites (max 15)</div>
    <div class="muted">
      Deze lijst komt uit de database: <code>sites</code> + <code>groups</code> + review telling.
    </div>

    <?php if (empty($sites)): ?>
      <div class="notice">Geen websites gevonden voor deze klas. Controleer of je seed/INSERT is uitgevoerd.</div>
    <?php endif; ?>

    <div class="grid">
      <?php foreach ($sites as $s): ?>
        <?php
          $count = (int)$s['review_count'];
          $pillClass = $count > 0 ? 'good' : 'warn';
        ?>
        <article class="card">
          <div class="card-head">
            <div>
              <strong><?= $s['title'] ?> – <?= $s['group_name'] ?></strong>
              <div class="meta"><?= $s['url'] ?></div>
            </div>
            <span class="pill <?= $pillClass ?>"><?= $count ?> reviews</span>
          </div>

          <div class="card-actions">
            <a class="btn sm" href="<?= $s['url'] ?>" target="_blank" rel="noopener">Open website</a>

            <?php if ($isTeacher): ?>
              <button class="btn sm"
                type="button"
                data-open-reviews
                data-title="<?= $s['title'].' – '.$s['group_name'] ?>"
                data-count="<?= $count ?>">
                Reviews
              </button>

              <button class="btn sm primary"
                type="button"
                data-open-edit
                data-site-id="<?= (int)$s['id'] ?>"
                data-group-id="<?= (int)$s['group_id'] ?>"
                data-group-name="<?= $s['group_name'] ?>"
                data-title="<?= $s['title'] ?>"
                data-url="<?= $s['url'] ?>">
                Aanpassen
              </button>
            <?php else: ?>
              <span class="pill info">Docentopties na login</span>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </section>

</div>

<footer>Home – data uit MySQL, sites zichtbaar voor iedereen</footer>
</body>
</html>
