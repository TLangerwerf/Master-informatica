<?php
declare(strict_types=1);

return [
  'db' => [
    'host' => 'localhost',
    'name' => 'wrp',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4',
  ],
  'session_name' => 'wrp_session',
];
